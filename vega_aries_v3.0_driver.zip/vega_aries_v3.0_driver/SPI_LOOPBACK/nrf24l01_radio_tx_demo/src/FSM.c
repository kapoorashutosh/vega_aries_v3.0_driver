/*
 * FSM.c
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */




/***************************************************


FSM code for VEGA ARIES 3.0 board
*/

#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"

typedef unsigned short US; // for unsigned short

uint8_t Transmit_Data = 0xFF; // command for accessing spi status byte


void spi_interface_test()
{
	//printf("ADF is interfaced with host device");
		SPI_init(MDP_SPI_1); // for the SPI0, SPI initialization function with its required configuration for mode 3 (ideal high and data sampled on falling edge [2nd edge])
		//asserting cs pin from high to low
		SPI_set_CSAAT_pin(MDP_SPI_1, 1);
		//The ADF7030-1 also reports status via a status byte. The ADF7030-1 returns this byte on the SPI MISO pin in response to a no operation
		//(NOP), 0xFF, on the SPI MOSI. The format of the status byte is shown in Table 6. in software manual page 15 of 80
		SPI_transmit(MDP_SPI_1,  Transmit_Data );
		// receiving SPI status byte
		SPI_receive(MDP_SPI_1 );
		//de-asserting cs pin from low to high
		SPI_set_CSAAT_pin(MDP_SPI_1, 0);
		//rxdata=SPI_receive(MDP_SPI_0 );
		printf("ADF is interfaced with host device");
}

//void FSM()
//{




