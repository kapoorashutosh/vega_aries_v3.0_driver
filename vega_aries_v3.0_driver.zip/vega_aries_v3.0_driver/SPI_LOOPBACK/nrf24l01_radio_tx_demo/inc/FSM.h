/*
 * FSM.h
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_



void spi_interface_test();
void FSM();
#endif /* INC_FSM_H_ */
