/*
 * delay.h
 *
 *  Created on: May 26, 2025
 *      Author: ashutosh
 */

#ifndef DELAY_H_
#define DELAY_H_

#include <stdint.h>
#include <ctype.h>
#include <stdio.h>
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);



#endif /* DELAY_H_ */
