/*
 * timer_tx.c
 *
 *  Created on: JAN 8, 2026
 *      Author: ashutosh-cdac
 *///includes for timer_tx.c
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"

//timer variables initialization
uint32_t prev_time,curr_time;
uint32_t temp;
int stop =0;


//for clearing timer interrupt
void clear_timer_interrupt(UC timer_no)
{
    volatile UI eoi = Timer(timer_no).EOI;
    (void)eoi;
    __asm__ __volatile__("fence");
}

void timer0_interrupthandler()                                                     // Timer Handler function
{
// function needed to be done afert the timer expries
//Write the code which is required
 clear_timer_interrupt(TIMER_0);
 stop=1;
 //printf("\n********************<<Interrupt Raised>> ******************\n");
}

//adding timer isr function inside this function
void create_timer(void)
{
	timer_register_isr(TIMER_0, timer0_interrupthandler); // calling interrupt for TIMER 0
}

//timer ISR function for calling interrupt for timer 0


//Timer 1 parameter settings
//vega's timer is free running 32-bit always
//mode always in timer mode
//no Prescaler register is here so timer peripheral CLK working on 100 MHZ itself so 1 tick = 10ns
void start_get_timer_tx(void)
{
	// Stop timer first
	timer_disable(TIMER_1);

	// Load max count
	Timer(TIMER_1).LoadCount = 0xFFFFFFFF; //non stop count or maximum counts set to
	__asm__ __volatile__("fence");

	// Start timer + config bits all at once
	Timer(TIMER_1).Control = 0x05; //00000101 here bit 1 enables timer, bit 2 keep timer one shot and bit 3 masks the interrupt
	__asm__ __volatile__("fence");
	// start timer ; use this function if in timer.control the 1st bit  is set to 0 like u can enable timer from either of ways
	//timer_enable(TIMER_1);

}

//TIMESTAMP-function defination
uint32_t get_time_tx(void)
{
    uint32_t curr_time = timer_get_current_value(TIMER_1);   // captures the current value of timer
    uint32_t temp = prev_time;
    prev_time = curr_time;
    uint32_t ticks = (temp - curr_time);  // timer counts down
    return ticks / 100;  // convert ticks to microseconds
    //return (prev_time - temp);  // Return elapsed ticks
}

//Parameter settings for timer 0 that will be used for timeslot timperiod functionality
void start_timer_tx(void)
{
	// Stop timer first
	timer_disable(TIMER_0);

	// Load max count
	Timer(TIMER_0).LoadCount = 3000000; //30 ms time-period of time-slot according to 100 MHZ clk
	__asm__ __volatile__("fence");

	// Start timer + config bits all at once
	Timer(TIMER_0).Control = 0x03; //00000011 here bit 1 enables timer, bit 2 makes timer to reload and bit 3 enables the interrupt
	__asm__ __volatile__("fence");
	// start timer ; use this function[timer_enable(TIMER_0);] if in timer.control the 1st bit  is set to 0 like u can enable timer from either of ways
	//timer_enable(TIMER_0);

}











