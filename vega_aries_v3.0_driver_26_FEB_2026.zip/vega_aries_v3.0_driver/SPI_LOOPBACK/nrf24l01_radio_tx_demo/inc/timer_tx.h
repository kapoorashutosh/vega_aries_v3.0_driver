/*
 * timer_tx.h
 *
 *  Created on: Nov 6, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_TIMER_TX_H_
#define INC_TIMER_TX_H_

//function driver includes
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"

//varables for timers
extern uint32_t prev_time,curr_time;
extern int stop;
//function declaration
void timer0_interrupthandler();
uint32_t get_time_tx(void);
void start_get_timer_tx(void);//declaration of timer 1 parameters and  Initialization timer 1 function
void start_timer_tx(void);//declaration of timer 0 parameters and enabling it/ Initialization timer 0 function
void create_timer(void);
void clear_timer_interrupt(UC timer_no);
#endif /* INC_TIMER_TX_H_ */
