/*
 * configuration.c
 *
 *  Created on: Dec 30, 2025
 *      Author: ashutosh-cdac
 */

//Includes
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/configuration.h"
#include "spi.h"
//these are the configuration array buffers at different configuration address of respective registers where further the things would be like address would be set OR are the configuration arrays wriiten  to their respective address with configuration data accordingly such as for payload address at its configuratin cfg0 address and etc for the other configuration address for configuring the other stuff with their particular data that has been written into the respective configuration buffers


//congig_array_1 to be written at 200002E4
int config_array_1[133] = {0x38, 0x20, 0x00, 0x02, 0xE4,
0x00, 0x3C, 0x78, 0x6E, 0x11, 0x8C, 0xBA, 0x80,
0x33, 0xBC, 0xA1, 0x00, 0x00, 0x04, 0xF5, 0x88,
0x00, 0x00, 0x44, 0xF4, 0x12, 0x00, 0x00, 0x02,
0x64, 0x00, 0x05, 0x74, 0x01, 0x1A, 0x58, 0x50,
0x88, 0x6E, 0x60, 0x0C, 0x00, 0x00, 0x01, 0xF4,
0x00, 0x00, 0x00, 0x04, 0x00, 0xF2, 0x04, 0x30,
0x5E, 0x02, 0x24, 0x80, 0x0F, 0x02, 0x0F, 0x14,
0x00, 0x05, 0x03, 0x1E, 0x25, 0x28, 0x00, 0x02,
0x92, 0xE7, 0x03, 0xF0, 0x00, 0x86, 0x03, 0x24,
0xDC, 0x1C, 0x32, 0xA0, 0x10, 0x00, 0x06, 0x00,
0x40, 0x60, 0x7F, 0x02, 0x00, 0x00, 0x00, 0x40,
0x00, 0x00, 0x00, 0x00, 0x0C, 0x01, 0x00, 0x28,
0x02, 0x00, 0x10, 0x9C, 0xFC, 0xC0, 0x64, 0x0A,
0x00, 0x05, 0x90, 0xC8, 0x34, 0x38, 0x3C, 0x59,
0x7C, 0x03, 0x01, 0x10, 0x04, 0x33, 0xC8, 0x76,
0x10, 0x2F, 0xD3, 0x0A, 0x80, 0x99, 0x90, 0x02};

int config_array_1b[141] = {0x38, 0x20, 0x00, 0x03, 0x64,
0x20, 0x00, 0x06, 0x0C, 0x00, 0x04, 0x04, 0x01,
0x08, 0x14, 0x35, 0x0B, 0x00, 0x10, 0x00, 0x10,
0x02, 0x90, 0x01, 0x6A, 0x06, 0xC0, 0x0E, 0x43,
0x00, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x0A, 0xE0, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x01, 0xDC, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x00};

//congig_array_2 to be written at 2000060C
int config_array_2[29] = {0x38, 0x20, 0x00, 0x06, 0x0C,
0x36, 0x7C, 0x03, 0x00, 0x00, 0x01, 0x00, 0x27,
0x69, 0x02, 0x6A, 0x94, 0x69, 0x00, 0xC0, 0x94,
0x69, 0x00, 0xA5, 0x94, 0x69, 0x00, 0xA8, 0x94};

//congig_array_3 to be written at 20000624
int config_array_3[29] = {0x38, 0x20, 0x00, 0x06, 0x24,
0x20, 0x7C, 0x00, 0x1F, 0x00, 0x01, 0x00, 0x1A,
0xE1, 0xC0, 0xE0, 0x32, 0xC0, 0xC0, 0xE0, 0x32,
0xE0, 0xC0, 0xE5, 0x36, 0xEC, 0x14, 0x0E, 0x3E};


//congig_array_4 to be written at 2000063C
int config_array_4[29] = {0x38, 0x20, 0x00, 0x06, 0x3C,
0x12, 0x0C, 0x01, 0x00, 0x00, 0x01, 0x00, 0xA1,
0xB2, 0x81, 0xA0, 0xDB, 0xB2, 0x81, 0xA0, 0xDB,
0xB2, 0x80, 0xE1, 0xDB, 0xB2, 0x00, 0xE6, 0xDB};

//congig_array_5 to be written at 200006B4
int config_array_5[37] = {0x38, 0x20, 0x00, 0x06, 0xB4,
0x3F, 0x3B, 0x7F, 0x23, 0x3D, 0xCB, 0x7D, 0xB3,
0x3C, 0x98, 0x7C, 0x80, 0x3B, 0xBD, 0x7B, 0xA5,
0x3B, 0x4B, 0x7B, 0x33, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};


//congig_array_6 to be written at 200006D4
int config_array_6[37] = {0x38, 0x20, 0x00, 0x06, 0xD4,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

//congig_array_7 to be written at 20000794
int config_array_7[25] = {0x38, 0x20, 0x00, 0x07, 0x94,
0x00, 0x00, 0x01, 0x24, 0x2B, 0xA3, 0x39, 0xDC,
0x48, 0x72, 0x41, 0x8A, 0x00, 0x00, 0x13, 0xD5,
0x00, 0x00, 0x00, 0x00};

//congig_array_8 to be written at 200007A8
int config_array_8[25] = {0x38, 0x20, 0x00, 0x07, 0xA8,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x0};

//congig_array_9 to be written at 20000864
int config_array_9[33] = {0x38, 0x20, 0x00, 0x08, 0x64,
0x00, 0x1A, 0x00, 0x2E, 0x00, 0x1B, 0x3B, 0x57,
0x00, 0x00, 0x17, 0x00, 0x00, 0x1B, 0x37, 0x52,
0x0E, 0x29, 0x45, 0x60, 0x1B, 0x37, 0x52, 0x6E,
0x00, 0x00, 0x00, 0x00};

//congig_array_10 to be written at 200004F4
int config_array_10[113] = {0x38, 0x20, 0x00, 0x04, 0xF4,
0x00, 0x15, 0xE3, 0x06, 0x00, 0x01, 0x00, 0x80,
0xD0, 0x10, 0x00, 0x04, 0x00, 0x00, 0x10, 0x17,
0x08, 0x55, 0x08, 0x80, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x47, 0xFC, 0x10, 0x28,
0x00, 0x00, 0x6F, 0x4E, 0x00, 0x00, 0x90, 0x4E,
0x00, 0x00, 0x10, 0x21, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0xF1, 0x02, 0x70, 0x00, 0x00, 0x00,
0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x44, 0x37, 0x43, 0x31,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00};

//congig_array_11 to be written at 200000C0
int config_array_11[9] = {0x38, 0x20, 0x00, 0x00, 0xC0,
0x24, 0x03, 0x60, 0xD0};

//congig_array_12 to be written at 20003E04
int config_array_12[33] = {0x38,
0x40, 0x00, 0x3E, 0x04, 0x00, 0x00, 0x00, 0xC0,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x3A, 0x9D};

//congig_array_13 to be written at 20000AE0
int config_array_13[33] = {0x38,
0x20, 0x00, 0x0A, 0xE0, 0x00, 0x00, 0x00, 0x02,
0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x3A, 0x9D,
0x3E, 0x10, 0x3E, 0x04};

//congig_array_14 to be written at 200042A4
int config_array_14[9] = {0x38,
0x40, 0x00, 0x42, 0xA4, 0x04, 0x00, 0x00, 0x00};



int i_2=0;
uint16_t word = 0; //16 bit buffer \2byte
void config_all()
{
  //transmitting config array 1
	//printf("Hello1");
	SPI_init(MDP_SPI_1);
	//printf("Helloddd");
	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
  for(i_2=0;i_2<=132;i_2+=2)
  {
	  //printf("Hello2");
	  word = ((uint16_t)config_array_1[i_2] << 8);

	 	                    	         /* Check if next byte exists */
	 	                    	         if (i_2 + 1 <= 132)
	 	                    	         {
	 	                    	             word |= config_array_1[i_2 + 1];
	 	                    	         }
	 	                    	         else
	 	                    	         {
	 	                    	             /* Padding for odd byte count */
	 	                    	             word |= 0x00;
	 	                    	         }
	                                         // transmitting the configured array
	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
  //printf("Hello3.555555");
  }
  //printf("Hello4");
  word = 0;
  delay_us(1000);
  SPI_set_CSAAT_pin(MDP_SPI_1, 0);
  //printf("Hello5");

  //transmitting config array 1_b
  //SPI_init(MDP_SPI_1);
  delay_us(100);
  	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
    for(i_2=0;i_2<=140;i_2+=2)
    {
    	 word = ((uint16_t)config_array_1b[i_2] << 8);

    		                    	         /* Check if next byte exists */
    		                    	         if (i_2 + 1 <= 140)
    		                    	         {
    		                    	             word |= config_array_1b[i_2 + 1];
    		                    	         }
    		                    	         else
    		                    	         {
    		                    	             /* Padding for odd byte count */
    		                    	             word |= 0x00;
    		                    	         }
    	                                        // transmitting the configured array
    		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
    }
    word = 0;
    delay_us(1000);
    SPI_set_CSAAT_pin(MDP_SPI_1, 0);

    //trasmitting config array 2
   // SPI_init(MDP_SPI_1);
    delay_us(100);
    	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
      for(i_2=0;i_2<=28;i_2+=2)
      {
    	  word = ((uint16_t)config_array_2[i_2] << 8);

    	 	                    	         /* Check if next byte exists */
    	 	                    	         if (i_2 + 1 <= 28)
    	 	                    	         {
    	 	                    	             word |= config_array_2[i_2 + 1];
    	 	                    	         }
    	 	                    	         else
    	 	                    	         {
    	 	                    	             /* Padding for odd byte count */
    	 	                    	             word |= 0x00;
    	 	                    	         }
    	                                         // transmitting the configured array
    	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
      }
      word = 0;
      delay_us(1000);
      SPI_set_CSAAT_pin(MDP_SPI_1, 0);

      //transmitting config array 3
      //SPI_init(MDP_SPI_1);
      delay_us(100);
      	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
        for(i_2=0;i_2<=28;i_2+=2)
        {
        	 word = ((uint16_t)config_array_3[i_2] << 8);

        		                    	         /* Check if next byte exists */
        		                    	         if (i_2 + 1 <= 28)
        		                    	         {
        		                    	             word |= config_array_3[i_2 + 1];
        		                    	         }
        		                    	         else
        		                    	         {
        		                    	             /* Padding for odd byte count */
        		                    	             word |= 0x00;
        		                    	         }
        	                                        // transmitting the configured array
        		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
        }
        word = 0;
        delay_us(1000);
        SPI_set_CSAAT_pin(MDP_SPI_1, 0);

        //trasnmitting config array 4

       // SPI_init(MDP_SPI_1);
        delay_us(100);
        	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
          for(i_2=0;i_2<=28;i_2+=2)
          {
        	  word = ((uint16_t)config_array_4[i_2] << 8);

        	 	                    	         /* Check if next byte exists */
        	 	                    	         if (i_2 + 1 <= 28)
        	 	                    	         {
        	 	                    	             word |= config_array_4[i_2 + 1];
        	 	                    	         }
        	 	                    	         else
        	 	                    	         {
        	 	                    	             /* Padding for odd byte count */
        	 	                    	             word |= 0x00;
        	 	                    	         }
        	                                         // transmitting the configured array
        	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
          }
          word = 0;
          delay_us(1000);
          SPI_set_CSAAT_pin(MDP_SPI_1, 0);

          //transmitting confIG array 5

          //SPI_init(MDP_SPI_1);
          delay_us(100);
          	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
            for(i_2=0;i_2<=36;i_2+=2)
            {
            	 word = ((uint16_t)config_array_5[i_2] << 8);

            		                    	         /* Check if next byte exists */
            		                    	         if (i_2 + 1 <= 36)
            		                    	         {
            		                    	             word |= config_array_5[i_2 + 1];
            		                    	         }
            		                    	         else
            		                    	         {
            		                    	             /* Padding for odd byte count */
            		                    	             word |= 0x00;
            		                    	         }
            	                                        // transmitting the configured array
            		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
            }
            word = 0;
            delay_us(1000);
            SPI_set_CSAAT_pin(MDP_SPI_1, 0);

            //transmmitng config array 6

            //SPI_init(MDP_SPI_1);
            delay_us(100);
            	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
              for(i_2=0;i_2<=36;i_2+=2)
              {
            	  word = ((uint16_t)config_array_6[i_2] << 8);

            	 	                    	         /* Check if next byte exists */
            	 	                    	         if (i_2 + 1 <= 36)
            	 	                    	         {
            	 	                    	             word |= config_array_6[i_2 + 1];
            	 	                    	         }
            	 	                    	         else
            	 	                    	         {
            	 	                    	             /* Padding for odd byte count */
            	 	                    	             word |= 0x00;
            	 	                    	         }
            	                                         // transmitting the configured array
            	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
              }
              word = 0;
              delay_us(1000);
              SPI_set_CSAAT_pin(MDP_SPI_1, 0);

              //transmitting config array 7
             // SPI_init(MDP_SPI_1);
              delay_us(100);
              	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                for(i_2=0;i_2<=24;i_2+=2)
                {
                	 word = ((uint16_t)config_array_7[i_2] << 8);

                		                    	         /* Check if next byte exists */
                		                    	         if (i_2 + 1 <= 24)
                		                    	         {
                		                    	             word |= config_array_7[i_2 + 1];
                		                    	         }
                		                    	         else
                		                    	         {
                		                    	             /* Padding for odd byte count */
                		                    	             word |= 0x00;
                		                    	         }
                	                                        // transmitting the configured array
                		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                }
                word = 0;
                delay_us(1000);
                SPI_set_CSAAT_pin(MDP_SPI_1, 0);


                //transmititng config array 8
               // SPI_init(MDP_SPI_1);
                delay_us(100);
                	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                  for(i_2=0;i_2<=24;i_2+=2)
                  {
                	  word = ((uint16_t)config_array_8[i_2] << 8);

                	 	                    	         /* Check if next byte exists */
                	 	                    	         if (i_2 + 1 <= 24)
                	 	                    	         {
                	 	                    	             word |= config_array_8[i_2 + 1];
                	 	                    	         }
                	 	                    	         else
                	 	                    	         {
                	 	                    	             /* Padding for odd byte count */
                	 	                    	             word |= 0x00;
                	 	                    	         }
                	                                         // transmitting the configured array
                	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                  }
                  word = 0;
                  delay_us(1000);
                  SPI_set_CSAAT_pin(MDP_SPI_1, 0);


                  //transmiting config array 9
                  //SPI_init(MDP_SPI_1);
                  delay_us(100);
                  	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                    for(i_2=0;i_2<=32;i_2+=2)
                    {
                    	 word = ((uint16_t)config_array_9[i_2] << 8);

                    		                    	         /* Check if next byte exists */
                    		                    	         if (i_2 + 1 <= 32)
                    		                    	         {
                    		                    	             word |= config_array_9[i_2 + 1];
                    		                    	         }
                    		                    	         else
                    		                    	         {
                    		                    	             /* Padding for odd byte count */
                    		                    	             word |= 0x00;
                    		                    	         }
                    	                                        // transmitting the configured array
                    		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                    }
                    word = 0;
                    delay_us(1000);
                    SPI_set_CSAAT_pin(MDP_SPI_1, 0);

                    //transmitting config array 10, this one is the configuring array for payload tx and rx
                    //SPI_init(MDP_SPI_1);
                  //  delay_us(100);
                    /*	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                      for(i_2=0;i_2<132;i_2+=2)
                      {
                    	   // m_tx_buf[i_2]=config_array_10[i_2];
                    	 // m_tx_buf[i_2+1]=config_array_10[i_2+1];
                    	     // uint16_t word = ((uint16_t)m_tx_buf[i_2] << 8) | m_tx_buf[i_2+1];
                    	      uint16_t word = ((uint16_t)config_array_10[i_2] << 8) | config_array_10[i_2+1];
                      }
                      SPI_write_tx_reg(MDP_SPI_1,word);
                       Write last remaining byte (index 132)
                          uint16_t last_word =
                              ((uint16_t)config_array_1[132] << 8);

                          SPI_write_tx_reg(MDP_SPI_1, last_word);

                      word = 0;
                      delay_us(1000);
                      SPI_set_CSAAT_pin(MDP_SPI_1, 0);*/


	  //transmitting config array 10, this one is the configuring array for payload tx and rx
	  SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	                      for(i_2=0;i_2<=132;i_2+=2)
	                      {
	                    	   word = ((uint16_t)config_array_10[i_2] << 8);

	                    	         /* Check if next byte exists */
	                    	         if (i_2 + 1 <= 132)
	                    	         {
	                    	             word |= config_array_10[i_2 + 1];
	                    	         }
	                    	         else
	                    	         {
	                    	             /* Padding for odd byte count */
	                    	             word |= 0x00;
	                    	         }
                                        // transmitting the configured array
	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
	                    	     }
	                      word = 0;
	                                            delay_us(1000);
	                                            SPI_set_CSAAT_pin(MDP_SPI_1, 0);

                      //trasnmitting config array 11

                      //SPI_init(MDP_SPI_1);
                      delay_us(100);
                      	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                        for(i_2=0;i_2<=8;i_2+=2)
                        {
                        	 word = ((uint16_t)config_array_11[i_2] << 8);

                        		                    	         /* Check if next byte exists */
                        		                    	         if (i_2 + 1 <= 8)
                        		                    	         {
                        		                    	             word |= config_array_11[i_2 + 1];
                        		                    	         }
                        		                    	         else
                        		                    	         {
                        		                    	             /* Padding for odd byte count */
                        		                    	             word |= 0x00;
                        		                    	         }
                        	                                        // transmitting the configured array
                        		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                        }
                        word = 0;
                        delay_us(1000);
                        SPI_set_CSAAT_pin(MDP_SPI_1, 0);

                        //trasnmitint config array 12

                        //SPI_init(MDP_SPI_1);
                        delay_us(100);
                        	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                          for(i_2=0;i_2<=32;i_2+=2)
                          {
                        	  word = ((uint16_t)config_array_12[i_2] << 8);

                        	 	                    	         /* Check if next byte exists */
                        	 	                    	         if (i_2 + 1 <= 32)
                        	 	                    	         {
                        	 	                    	             word |= config_array_12[i_2 + 1];
                        	 	                    	         }
                        	 	                    	         else
                        	 	                    	         {
                        	 	                    	             /* Padding for odd byte count */
                        	 	                    	             word |= 0x00;
                        	 	                    	         }
                        	                                         // transmitting the configured array
                        	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                          }
                          word = 0;
                          delay_us(1000);
                          SPI_set_CSAAT_pin(MDP_SPI_1, 0);

                          //TRASNMITTING CONFIG ARRAY 13

                          //SPI_init(MDP_SPI_1);
                          delay_us(100);
                          	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                            for(i_2=0;i_2<=32;i_2+=2)
                            {
                            	 word = ((uint16_t)config_array_13[i_2] << 8);

                            		                    	         /* Check if next byte exists */
                            		                    	         if (i_2 + 1 <= 32)
                            		                    	         {
                            		                    	             word |= config_array_13[i_2 + 1];
                            		                    	         }
                            		                    	         else
                            		                    	         {
                            		                    	             /* Padding for odd byte count */
                            		                    	             word |= 0x00;
                            		                    	         }
                            	                                        // transmitting the configured array
                            		                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                            }
                            word = 0;
                            delay_us(1000);
                            SPI_set_CSAAT_pin(MDP_SPI_1, 0);

                            //TRASNMITTING CONFIG ARRAY 14

                           // SPI_init(MDP_SPI_1);
                            delay_us(100);
                            	              SPI_set_CSAAT_pin(MDP_SPI_1, 1);
                              for(i_2=0;i_2<=8;i_2+=2)
                              {
                            	  word = ((uint16_t)config_array_14[i_2] << 8);

                            	 	                    	         /* Check if next byte exists */
                            	 	                    	         if (i_2 + 1 <= 8)
                            	 	                    	         {
                            	 	                    	             word |= config_array_14[i_2 + 1];
                            	 	                    	         }
                            	 	                    	         else
                            	 	                    	         {
                            	 	                    	             /* Padding for odd byte count */
                            	 	                    	             word |= 0x00;
                            	 	                    	         }
                            	                                         // transmitting the configured array
                            	 	                    	         SPI_write_tx_reg(MDP_SPI_1, word);
                              }
                              word = 0;
                              delay_us(1000);
                              SPI_set_CSAAT_pin(MDP_SPI_1, 0);

}













