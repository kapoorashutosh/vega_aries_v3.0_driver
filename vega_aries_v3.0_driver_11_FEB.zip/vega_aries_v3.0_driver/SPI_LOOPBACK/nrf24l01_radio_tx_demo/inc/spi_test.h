/*
 * spi_test.h
 *
 *  Created on: Nov 10, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_SPI_TEST_H_
#define INC_SPI_TEST_H_

//includes
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
//file inculdes
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"

void FSM_STATE(void);

#endif /* INC_SPI_TEST_H_ */
