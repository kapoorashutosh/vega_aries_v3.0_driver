/*
 * read_write_function.h
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_READ_WRITE_FUNCTION_H_
#define INC_READ_WRITE_FUNCTION_H_

#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "interrupt.h"
//file inculdes
#include "stdbool.h"
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/configuration.h"

//tx and rx variables for spi transfer and receive

extern uint8_t m_tx_buf[150];
 extern uint8_t m_rx_buf[150];
extern uint16_t zzz;
//extern long ASN =0;
extern long ASN ;
extern int ASN_count;
extern long asn;
extern int CurTimeslot;
extern int length;
extern int pad_data;
//extern  uint8_t ax;
//extern uint8_t bx;
 //function declaration
void set_GENERIC_PKT_FRAME_CFG5_reg();
void set_GENERIC_PKT_FRAME_CFG1_reg();
 void read_MISC_FW_reg();
  void channel_write(long);
  static void static_channel_write(int);
  void read_address(long);
  void read_Packet(void);
  void read_Ack(void);
  void write_address(long, long);
 void Test_timeslot_rx(void);
 void READ_PACKET(void);
 void write_Packet(long);
 void write_Ack(long);
 void check_length_and_padding(void);
 void timeslot(void);
 void timeslot_tx(void);
 void start_gpiote_tx(void);
void ADF7030InterruptHandler(void);
void clear_interrupts(void);
void write_EB(long);
void receive_EB();
void broadcast_EB(void);
void Enhanced_Beacon();
//int* read_EB(int);
void read_EB();

#endif /* INC_READ_WRITE_FUNCTION_H_ */
