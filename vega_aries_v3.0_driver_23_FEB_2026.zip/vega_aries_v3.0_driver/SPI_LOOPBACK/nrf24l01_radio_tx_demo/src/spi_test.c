/*
 * spi_test.c
 *
 *  Created on: Nov 10, 2025
 *      Author: ashutosh-cdac
 */


//Includes
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/spi_test.h"

void FSM_STATE()
{
	FSM(PHY_OFF);
		delay_us(500);
		FSM(CFG_DEV);
		delay_us(1000);
		//printf(" phy_on state command \n");
		FSM(PHY_ON);
		delay_us(500);
		channel_write(1);	 // writing frequency to register
		delay_us(500);
		//State();

		//FSM(DO_CAL);
		//delay_us(5000);
		write_Packet(1);
		delay_us(500);
		State();
		//printf(" phy_tx state command \n");
		//clear_interrupts();
		FSM(PHY_TX);
		delay_us(1000);
		State();
		/*FSM(PHY_RX);
		delay_us(1000);
		State();*/
		FSM(PHY_ON);
		delay_us(1000);
		State();
		FSM(PHY_OFF);
		State();
}
