/*
 * read_write_function.c
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
#include "stdbool.h"
#include <string.h>
#include "interrupt.h"
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/configuration.h"

//defining pin for receiving IRQ interrupt
#define IRQ_PIN 10

uint8_t m_tx_buf[150];   //TX buffer
uint8_t m_rx_buf[150];  //RX buffer
uint16_t zzz; // 16 bit receive buffer
uint16_t knk;
uint16_t qwq;
uint32_t adf_freq, f;
int length = 0;
int pad_data = 0;
//long ASN =0;
int look_up_table[4] = { 0x337055C0, 0x3371DC60, 0x33736300, 0x3374E9A0 }; // Look up table for frequency hopping
//ASN variable
long ASN = 0;
int ASN_count = 0;
long asn;
int CurTimeslot = 0;
//uint8_t ax;
//uint8_t bx;
struct LinkTable {
	int macLinkHandle;
	uint8_t state; //macRxType<<1|macTxType
	bool macSharedType;
	bool macLinkTimeKeeping;
	bool macPriorityType;
	bool macLinkType;
	bool macNodeAddressMode; //0 for long addres 1 for short address. In standard
	double macNodeAddress;
	int macTimeslot;
	int macChannelOffset;
	bool macLinkAdvertise;
} macLinkTable[4];

//IE variables
int i_EB=28;//initialize i to index of hte1+1 index for IE
bool type;//type of IE 0/1
int len_IE;//Length of IE
int IE_ID;//ID of the IE
int j=0;  // to access each nested IE
int k; // to access index of IE array

int channel_id=0;    //channel id is extracted to find which link descriptor we need to access
int num_of_channels=0;// to changes asn%n -->n=numbeer of channel
int timeslot_numb[4]={0,0,0,0};
int timeslot_len=0;
int channel_offset[4]={0,0,0,0};
int Link_option[4]={0,0,0,0};
int IE[11]={0,0,0,0,0,0,0,0,0,0,0}; //array to return IEs to called function, increase the index if more IE are needed to be returned




//fuction for reading data at a address


void read_address(long addx) {
	uint16_t nn;
	uint8_t h;
	// mode 1 memory access mode in read mode  (pg no 47 of ADF software manual)
	m_tx_buf[0] = 0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1, MHPTR=000 (dont care) -->01111000
	m_tx_buf[1] = addx >> 24;  // 1st Byte (MSB)
	m_tx_buf[2] = addx >> 16;  //2nd Byte
	m_tx_buf[3] = addx >> 8;  //3rd Byte
	m_tx_buf[4] = addx;  //4th Byte (LSB)
	for (h = 5; h <= 87; h++) {
		m_tx_buf[h] = 0x00;
	}
	//writing spi function for transmit and receive
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 87; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		nn = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 87) {
			nn |= m_tx_buf[j + 1];
		} else {
			// Padding for odd byte count
			nn |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, nn);

		uint16_t knk = SPI_read_rx_reg(MDP_SPI_1);

		//reading the data into the bufffer form knk vriable
		m_rx_buf[j] = ((knk >> 8) & 0xFF);  // MSB
				m_rx_buf[j + 1] = (knk & 0xFF);  // LSB
				printf("Buffer: 0x%x\n\r", m_rx_buf[j]);
				printf("Suffer: 0x%x\n\r", m_rx_buf[j+1]);
	}
		delay_us(250);

	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}




/*void read_address(long addx) {
	uint16_t nn;
	uint8_t h;
	// mode 1 memory access mode in read mode  (pg no 47 of ADF software manual)
	m_tx_buf[0] = 0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1, MHPTR=000 (dont care) -->01111000
	m_tx_buf[1] = addx >> 24;  // 1st Byte (MSB)
	m_tx_buf[2] = addx >> 16;  //2nd Byte
	m_tx_buf[3] = addx >> 8;  //3rd Byte
	m_tx_buf[4] = addx;  //4th Byte (LSB)
	for (h = 5; h <= 10; h++) {
		m_tx_buf[h] = 0x00;
	}
	//writing spi function for transmit and receive
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 10; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		nn = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 10) {
			nn |= m_tx_buf[j + 1];
		} else {
			// Padding for odd byte count
			nn |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, nn);

		uint16_t knk = SPI_read_rx_reg(MDP_SPI_1);
		for (int i = 30; i < 40; i++) {
		 m_rx_buf[i] = (uint8_t) (knk);
		 printf("%c", m_rx_buf[i]);
		 }

		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}*/

//function for writing data to a address
void write_address(long addx, long datax) {
	uint16_t Gx;
	//Memory acccess mode 1 in write format
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = addx >> 24; //1st byte ofAddress of the register
	m_tx_buf[2] = addx >> 16; //2nd byte ofAddress of the register
	m_tx_buf[3] = addx >> 8; //3rd byte ofAddress of the register
	m_tx_buf[4] = addx; //4th byte ofAddress of the register
	m_tx_buf[5] = datax >> 24;   //1st byte MSB part
	m_tx_buf[6] = datax >> 16;   //2nd byte
	m_tx_buf[7] = datax >> 8;   //#rd byte
	m_tx_buf[8] = datax;   //4th byte LSB part

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;

	for (j = 0; j <= 8; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		Gx = ((uint16_t) m_tx_buf[j] << 8);
		//uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;
		if (j + 1 <= 8) {
			Gx |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			Gx |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, Gx);
		// uint16_t ttt = SPI_read_rx_reg(MDP_SPI_1);

		delay_us(100);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}

//clear interrupt function for clearing the interrupt form adf
void clear_interrupts() {
	uint16_t Gx;
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = 0x40; //1st byte ofAddress of the register
	m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
	m_tx_buf[3] = 0x38; //3rd byte ofAddress of the register
	m_tx_buf[4] = 0x08; //4th byte ofAddress of the register
	m_tx_buf[5] = 0X09;   //1st byte
	m_tx_buf[6] = 0X51;   //2nd byte
	m_tx_buf[7] = 0X1F;   //#rd byte
	m_tx_buf[8] = 0XFF;   //4th byte

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;

	for (j = 0; j <= 8; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		Gx = ((uint16_t) m_tx_buf[j] << 8);
		//uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;
		if (j + 1 <= 8) {
			Gx |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			Gx |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, Gx);
		// uint16_t ttt = SPI_read_rx_reg(MDP_SPI_1);

		delay_us(100);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}

void set_GENERIC_PKT_FRAME_CFG5_reg() {
	uint16_t Gx;
	//Memory acccess mode 1 in write format
	read_address((long) 0x200000510);
	int TX_PHR = (MODE_SWITCH << 15) | 0x0000 | (FCS_TYPE << 12)
			| (DATA_WHITENING << 11) | ((length + 2) & 0x07FF); //0X0149 FOR EB of length 72
	printf("\nTX_PHR %x", TX_PHR);
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = 0x20; //1st byte ofAddress of the register
	m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
	m_tx_buf[3] = 0x05; //3rd byte ofAddress of the register
	m_tx_buf[4] = 0x10; //4th byte ofAddress of the register
	m_tx_buf[5] = m_rx_buf[7];   //1st byte
	m_tx_buf[6] = m_rx_buf[8];   //2nd byte
	m_tx_buf[7] = TX_PHR >> 8;   //#rd byte
	m_tx_buf[8] = TX_PHR;   //4th byte
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	// uint8_t z =4;
	//i = 0 → 0x78 << 8 | 0x40 → 0x7840
	//  i = 2 → 0x00 << 8 | 0x42 → 0x0042
	// i = 4 → 0xB4 << 8 | 0x00 → 0xB400   (padded)

	for (j = 0; j <= 8; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		Gx = ((uint16_t) m_tx_buf[j] << 8);
		//uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;
		if (j + 1 <= 8) {
			Gx |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			Gx |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, Gx);
		// uint16_t ttt = SPI_read_rx_reg(MDP_SPI_1);

		delay_us(100);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}

//setting interrupt IRQ0 to full packet received interrupt , refer pg 72 of software manual means enabling the interrupt
void set_GENERIC_PKT_FRAME_CFG1_reg() {
	uint16_t Gx;
	read_address(0x20000500);
	m_rx_buf[9] = (uint8_t) (knk);
	m_rx_buf[10] = (uint8_t) (knk);
	//Memory acccess mode 1 in write format
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = 0x20; //1st byte ofAddress of the register
	m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
	m_tx_buf[3] = 0x05; //3rd byte ofAddress of the register
	m_tx_buf[4] = 0x00; //4th byte ofAddress of the register
	//Data Bytes
	m_tx_buf[5] = 0x00;   //1st byte MSB byte
	//m_tx_buf[6] = 0x80; //2nd byte // Generic packet and IEEE 802.15.4g-2012: the full packet has been received (Rx); the full packet  has been transmitted (Tx).
	//m_tx_buf[6]=0x84; // EOF[for full packet received interrupt] and SFD   interrupt enabled [0x80 | 0x04]
	m_tx_buf[6]=0x04; //afd or sync word interrupt
	m_tx_buf[7] = m_rx_buf[9];   //#3rd byte
	m_tx_buf[8] = m_rx_buf[10];   //4th byte LSB byte
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	// uint8_t z =4;
	//i = 0 → 0x78 << 8 | 0x40 → 0x7840
	//  i = 2 → 0x00 << 8 | 0x42 → 0x0042
	// i = 4 → 0xB4 << 8 | 0x00 → 0xB400   (padded)

	for (j = 0; j <= 8; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		Gx = ((uint16_t) m_tx_buf[j] << 8);
		//uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;
		if (j + 1 <= 8) {
			Gx |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			Gx |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, Gx);
		// uint16_t ttt = SPI_read_rx_reg(MDP_SPI_1);

		delay_us(100);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}

// function defination for FSM state memory access register

void read_MISC_FW_reg() { // mode 1 memory access mode in read mode  (pg no 47 of ADF software manual)
	uint8_t h;
	m_tx_buf[0] = 0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1, MHPTR=000 (dont care) -->01111000
	m_tx_buf[1] = 0x40;  // 1st Byte (MSB)
	m_tx_buf[2] = 0x00;  //2nd Byte
	m_tx_buf[3] = 0x42;  //3rd Byte
	m_tx_buf[4] = 0xB4;  //4th Byte (LSB)
/*	m_tx_buf[5] = 0x00;  // Dummy bytes to clock out remaining data
	m_tx_buf[6] = 0x00;
	m_tx_buf[7] = 0x00;
	m_tx_buf[8] = 0x00;
	m_tx_buf[9] = 0x00;
	m_tx_buf[10] = 0x00;*/
	for(h=5; h <=10; h++){
		m_tx_buf[h] = 0x00;
	}
	//  GPIO_write_pin(39, 1); //setting cs pin high as cssat in spiint is low by default

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	// uint8_t z =4;
	//i = 0 → 0x78 << 8 | 0x40 → 0x7840
	//  i = 2 → 0x00 << 8 | 0x42 → 0x0042
	// i = 4 → 0xB4 << 8 | 0x00 → 0xB400   (padded)

	for (j = 0; j <= 10; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		uint16_t word = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 10) {
			word |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			word |= 0x00;
		}
		//  uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;

		SPI_write_tx_reg(MDP_SPI_1, word);

		zzz = SPI_read_rx_reg(MDP_SPI_1);
		//m_rx_buf[j]= SPI_read_rx_reg(MDP_SPI_1);
		//if(z <= 4)  // Changed from z<=5 to z<=4 since we write 2 bytes per iteration
		//{
//             m_rx_buf[j] = (uint8_t)(zzz >> 8);       // MSB first
//             m_rx_buf[j+1] = (uint8_t)(zzz & 0xFF);   // LSB next
		//m_rx_buf[j] = (uint8_t)(zzz >> 8);      // MSB position
		//  m_rx_buf[j+1] = (uint8_t)(zzz & 0xFF); //lSB position

		//}
		// m_rx_buf[z] = (uint8_t)SPI_receive(MDP_SPI_1, 0 );

		delay_us(100);
	}
	//GPIO_write_pin(39, 1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
	//nrf_drv_spi_transfer(&spi,m_tx_buf,5,m_rx_buf,11);
	//Although we are reading 11 bytes 1st 7 bytes will be status bytes next 4 bytes is the data from ADF to host
	//nrf_delay_us(100);
	//for(i=7;i<11;i++)
	// printf("m_rx_buff[%d]: %x \n",i, m_rx_buf[i]);
//        m_rx_buf[4] = (uint8_t)(zzz); //9th byte
//        m_rx_buf[5] = (uint8_t)(zzz>>8); //10th byte
//        radio_state=m_rx_buf[4]&(0x3F);
//        status=m_rx_buf[5]&(0x03);
}

//Timeslot function for basic and logic for transmisiion



void write_EB(long asn)
{
	uint16_t AA;
        length=74;
        check_length_and_padding();
        set_GENERIC_PKT_FRAME_CFG5_reg();

//Memory acccess mode 1 in write format
        m_tx_buf[0] = 0x38;  //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
        m_tx_buf[1] = 0x20; //1st byte ofAddress of the register
        m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
        m_tx_buf[3] = 0x0A; //3rd byte ofAddress of the register
        m_tx_buf[4] = 0xF0; //4th byte ofAddress of the register
/*
	m_tx_buf[5] = 0x22; // FCF --> Frame control field [15:8] MSB
	m_tx_buf[6] = 0x00; // FCF --> Frame control field [7:0] LSB
	m_tx_buf[7] = 0x1C; // SEQ NUM -->Sequence number
	m_tx_buf[8] = 0x11; // Dest PAN Identifier --> [15:8] MSB
	m_tx_buf[9] = 0x11; // Dest PAN Identifier --> [7:0] MSB
	m_tx_buf[10] = 0x00; // Dest Address --> [63:56]
*/
	m_tx_buf[5] = 0xFF; // FCF --> Frame control field [15:8] MSB
	m_tx_buf[6] = 0xFF; // FCF --> Frame control field [7:0] LSB
	m_tx_buf[7] = 0xFF; // SEQ NUM -->Sequence number
	m_tx_buf[8] = 0xFF; // Dest PAN Identifier --> [15:8] MSB
	m_tx_buf[9] = 0xFF; // Dest PAN Identifier --> [7:0] MSB
	m_tx_buf[10] = 0xFF; // Dest Address --> [63:56]

	m_tx_buf[11] = 0x00; // Dest Address --> [55:48]
	m_tx_buf[12] = 0x00; // Dest Address --> [47:40]
	m_tx_buf[13] = 0x00; // Dest Address --> [39:32]
	m_tx_buf[14] = 0x00; // Dest Address --> [31:24]
	m_tx_buf[15] = 0x00; // Dest Address --> [23:16]
	m_tx_buf[16] = 0x22; // Dest Address --> [15:8]
	m_tx_buf[17] = 0x22; // Dest Address --> [7:0]
	m_tx_buf[18] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[19] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[20] = 0x00; // Source Address --> [63:56]
	m_tx_buf[21] = 0x00; // Source Address --> [55:48]
	m_tx_buf[22] = 0x00; // Source Address --> [47:40]
	m_tx_buf[23] = 0x00; // Source Address --> [39:32]
	m_tx_buf[24] = 0x00; // Source Address --> [31:24]
	m_tx_buf[25] = 0x00; // Source Address --> [23:16]
	m_tx_buf[26] = 0x11; // Source Address --> [15:8]
	m_tx_buf[27] = 0x11; // Source Address --> [7:0]
        //Header Termination IE HTE1 Length=0, Element ID=7E, Type=0
        m_tx_buf[28] = 0x1F;
        m_tx_buf[29] = 0x80;
        //For formats of IE  refer page 198 of the standard
        //TSCH Sync IEs  refer Pg no. 201
        m_tx_buf[30] = 0x06;//Length of IE in octects -->(5 bytes asn, 1 byte Join metric)
        m_tx_buf[31] = 0x1A;//0x1A= 0001 1010 ---> Type=0,Sub Id=0x1A
        m_tx_buf[32] = asn;  //ASN 1st byte
        m_tx_buf[33] = asn>>8; //ASN 2nd byte
        m_tx_buf[34] = asn>>16; //ASN 3rd byte
        m_tx_buf[35] = asn>>24; //ASN 4th byte
        m_tx_buf[36] = asn>>32; //ASN 5th byte
        m_tx_buf[37] = 0x01;  // Join metric
        //End pf TSCH Sync IEs
        //Channel hopping IE page 235
        m_tx_buf[38] = 0x05; // Length of IE
        m_tx_buf[39] = 0xC8; // Type and Sub ID
        m_tx_buf[40] = 0x00; // Hopping sequence ID
        //No Channel Page
        m_tx_buf[41] = 0x00; // Number of channels
        m_tx_buf[42] = 0x10; // Number of channels
        // No Phy Configuration
        //MAC extended bit map not present
        // Hopping sequence length and sequence are set to default value
      //  m_tx_buf[41] = 0x04;// Hopping sequence length
        //Refer pg 235 of the standard
        //m_tx_buf[42] = 0x17; //channel hopping number1 in hex
        //m_tx_buf[43] = 0x0F; //channel hopping number2 in hex
        //m_tx_buf[44] = 0x14; //channel hopping number3 in hex
        //m_tx_buf[45] = 0x0B; //channel hopping number4 in hex
        m_tx_buf[43] = (asn%16)>>8; // current hopping index
        m_tx_buf[44] = (asn%16); // current hopping index
        //End of Channel Hopping IEs
        //TSCH Timeslot IE Refer Pg no 203
        m_tx_buf[45] = 0x02;// Length of IE
        m_tx_buf[46] = 0x1C;//Type and Sub ID
        m_tx_buf[47] = 0x00;//Timeslot ID It follows default timming of the hardware hence we are mentioning only timeslot length
        m_tx_buf[48] = 0x0A;//Timeslot Length
        //End of TSCH Timeslot IE
        //TSCH Slot Frame and Link IE Refer Pg no. 201
        m_tx_buf[49] = 0x19;//Legth of IE
        m_tx_buf[50] = 0x1B;//Type and Sub ID
        m_tx_buf[51] = 0x01;// Number of slotframe
        //Start of slot frame descriptor 1
        m_tx_buf[52] = 0x01;// Slotframe handler
        m_tx_buf[53] = 0x00;// Slot frame size
        m_tx_buf[54] = 0x04;// Slot frame size
        m_tx_buf[55] = 0x04; //Number of Links
        // Link1 Information
        m_tx_buf[56] = 0x00; // Timeslot Number
        m_tx_buf[57] = 0x00; // Timeslot Number
        m_tx_buf[58] = 0x00; // Channel Offset
        m_tx_buf[59] = 0x00; // Channel Offset
        m_tx_buf[60] = 0x00; // Link options is priority
        // Link2 Information
        m_tx_buf[61] = 0x00; // Timeslot Number
        m_tx_buf[62] = 0x01; // Timeslot Number
        m_tx_buf[63] = 0x00; // Channel Offset
        m_tx_buf[64] = 0x01; // Channel Offset
        m_tx_buf[65] = 0x00; // Link options Rx link
        // Link3 Information
        m_tx_buf[66] = 0x00; // Timeslot Number
        m_tx_buf[67] = 0x02; // Timeslot Number
        m_tx_buf[68] = 0x00; // Channel Offset
        m_tx_buf[69] = 0x02; // Channel Offset
        m_tx_buf[70] = 0x00; // Link options Rx link
        // Link4 Information
        m_tx_buf[71] = 0x00; // Timeslot Number
        m_tx_buf[72] = 0x03; // Timeslot Number
        m_tx_buf[73] = 0x00; // Channel Offset
        m_tx_buf[74] = 0x03; // Channel Offset
        m_tx_buf[75] = 0x09; // Link options RX link
        // Link option  Figure 7-55
        // Tx Link = 1
        // Rx Link = 0
        // Shared Link = 0
        // Timekeeping = 1
        // Priority = 0
        //End of Slot frame descriptor 1
        //End of TSCH slotframe IE
        //Payload TerminationIE Length=0, Element ID=0xF, Type=1
        m_tx_buf[76] = 0x00;
        m_tx_buf[77] = 0x7C;
        m_tx_buf[78] = 0x0F;

        SPI_init(MDP_SPI_1);
        	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
        uint8_t j;

        	for (j = 0; j < 79; j = j + 2) {
        		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
        		AA = ((uint16_t) m_tx_buf[j] << 8);
        		if (j + 1 < 79) {
        			AA |= m_tx_buf[j + 1];
        		} else {
        			/* Padding for odd byte count */
        			AA |= 0x00;
        		}
        		SPI_write_tx_reg(MDP_SPI_1, AA);
        		// uint16_t ccc = SPI_read_rx_reg(MDP_SPI_1);
        	}
        		delay_us(250);

        	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
        }



void broadcast_EB()
{
  FSM(PHY_ON);
  static_channel_write(2); // check where to call this function, here or in void enhanced_beacon(as in 7242)
  //write_EB(ASN);
  write_EB(1);
  //write_Packet(ASN);
  printf("hiiiiii\n");
  read_address(0x20000AF0); //reading the contents of payload
 // read_address(0x20000C18); //reading the contents of payload
  FSM(PHY_TX);
  State();
  delay_us(13000);
  State();
  FSM(PHY_ON);

}



void timeslot_tx() {
	FSM(PHY_ON);
	channel_write(ASN);
	write_Packet(ASN);
	FSM(CCA);
	delay_us(1000);
	delay_us(10000);
	FSM(PHY_RX);
	delay_us(11000);
	//read_Ack();
	FSM(PHY_ON);
}

void timeslot_rx() {
	FSM(PHY_ON);
	channel_write(ASN); //added here,check where to call this function
	delay_us(250);
	FSM(PHY_RX);
	delay_us(11000);
	read_Packet();
	write_Ack(ASN);
	FSM(PHY_TX);
	delay_us(10000); //change in pan coordinator also
	FSM(PHY_ON);

}

void channel_write(long asn) {
	uint16_t AA;
	uint8_t x = (asn + macLinkTable[CurTimeslot].macChannelOffset) % 4;
	adf_freq = look_up_table[x];
	m_tx_buf[0] = 0x38; // Command to write the channel frequency in the ADF Register (Lower byte first)
	m_tx_buf[1] = 0x20; //address of the freaquency register in 7030 0x200002EC,
	m_tx_buf[2] = 0x00;
	m_tx_buf[3] = 0x02;
	m_tx_buf[4] = 0xEC;
	m_tx_buf[5] = (adf_freq >> 24);
	m_tx_buf[6] = (adf_freq >> 16);
	m_tx_buf[7] = (adf_freq >> 8);
	m_tx_buf[8] = adf_freq;

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 8; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		AA = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 8) {
			AA |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			AA |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, AA);
		// uint16_t ccc = SPI_read_rx_reg(MDP_SPI_1);

		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
}

//frequency hopping made for beacons
static void static_channel_write(int y)                                  // Frequency Hopping Method for adf 7030 written on 16-02-2023
{
	uint16_t AA;
      uint8_t x= y;    //For network creation done on 13-04-2022                                            // To get the index value for accesing the lookup table
      adf_freq = look_up_table[x] ;
      // adf_freq=0x3371DC60;
       //freq is in Hz...refer to pg. 430 of the 2020 std
       m_tx_buf[0] = 0x38;                                  // Command to write the channel frequency in the ADF Register (Lower byte first)
       m_tx_buf[1] = 0x20;                     //address of the frequency register in 7030 0x200002EC,
       m_tx_buf[2] = 0x00;
       m_tx_buf[3] = 0x02;
       m_tx_buf[4] = 0xEC;
       m_tx_buf[5] = (adf_freq >> 24);
       m_tx_buf[6] = (adf_freq >> 16);
       m_tx_buf[7] = (adf_freq >> 8);
       m_tx_buf[8] = adf_freq;
       SPI_init(MDP_SPI_1);
       	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
       	//GPIO_write_pin(39, 1);
       	uint8_t j;
       	for (j = 0; j <= 8; j = j + 2) {
       		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
       		AA = ((uint16_t) m_tx_buf[j] << 8);
       		if (j + 1 <= 8) {
       			AA |= m_tx_buf[j + 1];
       		} else {
       			/* Padding for odd byte count */
       			AA |= 0x00;
       		}
       		SPI_write_tx_reg(MDP_SPI_1, AA);
       		// uint16_t ccc = SPI_read_rx_reg(MDP_SPI_1);

       		delay_us(250);
       	}
       	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
       }



void check_length_and_padding(void) {
	uint8_t i = 0;
	if (length % 4 != 0) {
		pad_data = (4 - length % 4);
		for (i = length + 5; i < length + 5 + pad_data; i++) {
			m_tx_buf[i] = 0xBB;
			printf("\t%x\t%d", m_tx_buf[i], i);

		}
		length = length + pad_data;
		printf("\the length after padding is %d", length);
	} else
		printf(" NO Padding ");
}

void write_Packet(long asn) {
	uint16_t BB;
	length = 40; //giving length for PHR {HEADER}framer's header
	check_length_and_padding();
	set_GENERIC_PKT_FRAME_CFG5_reg();
	//Memory acccess mode 1 in write format
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = 0x20; //1st byte ofAddress of the register
	m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
	m_tx_buf[3] = 0x0A; //3rd byte ofAddress of the register
	m_tx_buf[4] = 0xF0; //4th byte ofAddress of the register
	m_tx_buf[5] = 0xDC; // FCF --> Frame control field [15:8] MSB
	m_tx_buf[6] = 0x51; // FCF --> Frame control field [7:0] LSB
	m_tx_buf[7] = 0x1C; // SEQ NUM -->Sequence number
	m_tx_buf[8] = 0x22; // Dest PAN Identifier --> [15:8] MSB
	m_tx_buf[9] = 0x22; // Dest PAN Identifier --> [7:0] MSB
	m_tx_buf[10] = 0x00; // Dest Address --> [63:56]
	m_tx_buf[11] = 0x00; // Dest Address --> [55:48]
	m_tx_buf[12] = 0x00; // Dest Address --> [47:40]
	m_tx_buf[13] = 0x00; // Dest Address --> [39:32]
	m_tx_buf[14] = 0x00; // Dest Address --> [31:24]
	m_tx_buf[15] = 0x00; // Dest Address --> [23:16]
	m_tx_buf[16] = 0x22; // Dest Address --> [15:8]
	m_tx_buf[17] = 0x22; // Dest Address --> [7:0]
	m_tx_buf[18] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[19] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[20] = 0x00; // Source Address --> [63:56]
	m_tx_buf[21] = 0x00; // Source Address --> [55:48]
	m_tx_buf[22] = 0x00; // Source Address --> [47:40]
	m_tx_buf[23] = 0x00; // Source Address --> [39:32]
	m_tx_buf[24] = 0x00; // Source Address --> [31:24]
	m_tx_buf[25] = 0x00; // Source Address --> [23:16]
	m_tx_buf[26] = 0x11; // Source Address --> [15:8]
	m_tx_buf[27] = 0x11; // Source Address --> [7:0]

	m_tx_buf[28] = 'H'; // Frame Payload
	m_tx_buf[29] = 'E'; // Frame Payload
	m_tx_buf[30] = 'l'; // Frame Payload
	m_tx_buf[31] = 'l'; // Frame Payload
	m_tx_buf[32] = 'o'; // Frame Payload
	m_tx_buf[33] = 'W'; // Frame Payload
	m_tx_buf[34] = 'o'; // Frame Payload
	m_tx_buf[35] = 'r'; // Frame Payload
	m_tx_buf[36] = 'l'; // Frame Payload
	m_tx_buf[37] = 'd'; // Frame Payload

	/*
	 m_tx_buf[28] = 0x48; // Frame Payload
	 m_tx_buf[29] = 0x45; // Frame Payload
	 m_tx_buf[30] = 0x4C; // Frame Payload
	 m_tx_buf[31] = 0x4C; // Frame Payload
	 m_tx_buf[32] = 0x4F; // Frame Payload
	 m_tx_buf[33] = 0x57; // Frame Payload
	 m_tx_buf[34] = 0x4F; // Frame Payload
	 m_tx_buf[35] = 0x52; // Frame Payload
	 m_tx_buf[36] = 0x4C; // Frame Payload
	 m_tx_buf[37] = 0x44; // Frame Payload
	 */
	m_tx_buf[38] = asn;
	m_tx_buf[39] = asn >> 8;
	m_tx_buf[40] = asn >> 16;
	m_tx_buf[41] = asn >> 24;
	m_tx_buf[42] = asn >> 32;
	m_tx_buf[43] = asn >> 40;
	m_tx_buf[44] = asn >> 48;

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 44; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		BB = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 44) {
			BB |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			BB |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, BB);
		//uint16_t fff = SPI_read_rx_reg(MDP_SPI_1);
		//  printf("0x%X", m_tx_buf[j]); //reading tx buf for debugging

		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);

}

//function for reading the packet that has been sent
void read_Packet() {
	uint16_t BB;
	uint8_t h;
	// Mode 1 memory access mode in read mode (per ADF7030-1 manual)
	m_tx_buf[0] = 0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1
	m_tx_buf[1] = 0x20; //address MSB
	m_tx_buf[2] = 0x00;
	m_tx_buf[3] = 0x0C;
	m_tx_buf[4] = 0x18; //address LSB
	for (h = 5; h <= 44; h++) {
		m_tx_buf[h] = 0x00;
	}
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 44; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		BB = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 44) {
			BB |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			BB |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, BB);

		qwq = SPI_read_rx_reg(MDP_SPI_1);
		m_rx_buf[j] = ((qwq >> 8) & 0xFF);  // MSB
		m_rx_buf[j + 1] = (qwq & 0xFF);  // LSB
		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
	// Print payload from byte 30 to 37 (10 chars: HelloWorld)
	for (int i = 30; i < 40; i++) {
		//m_rx_buf[i] = (uint8_t) (qwq);
		printf("%c", m_rx_buf[i]);
	}
	//printing ASN
	long asn = 0;
	for (int i = 0; i < 5; i++) {
		//m_rx_buf[40 + i] = (uint8_t) (qwq);
		asn |= ((long) m_rx_buf[40 + i]) << (8 * i);
	}
	// Print the full ASN number
	printf(" ASN = %lu\n", asn);
}

void write_Ack(long asn) {
	uint16_t BB;
	length = 40; //giving length for PHR {HEADER}framer's header
	check_length_and_padding();
	set_GENERIC_PKT_FRAME_CFG5_reg();
	//Memory acccess mode 1 in write format
	m_tx_buf[0] = 0x38; //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	m_tx_buf[1] = 0x20; //1st byte ofAddress of the register
	m_tx_buf[2] = 0x00; //2nd byte ofAddress of the register
	m_tx_buf[3] = 0x0A; //3rd byte ofAddress of the register
	m_tx_buf[4] = 0xF0; //4th byte ofAddress of the register
	m_tx_buf[5] = 0xDC; // FCF --> Frame control field [15:8] MSB
	m_tx_buf[6] = 0x51; // FCF --> Frame control field [7:0] LSB
	m_tx_buf[7] = 0x1C; // SEQ NUM -->Sequence number
	m_tx_buf[8] = 0x22; // Dest PAN Identifier --> [15:8] MSB
	m_tx_buf[9] = 0x22; // Dest PAN Identifier --> [7:0] MSB
	m_tx_buf[10] = 0x00; // Dest Address --> [63:56]
	m_tx_buf[11] = 0x00; // Dest Address --> [55:48]
	m_tx_buf[12] = 0x00; // Dest Address --> [47:40]
	m_tx_buf[13] = 0x00; // Dest Address --> [39:32]
	m_tx_buf[14] = 0x00; // Dest Address --> [31:24]
	m_tx_buf[15] = 0x00; // Dest Address --> [23:16]
	m_tx_buf[16] = 0x22; // Dest Address --> [15:8]
	m_tx_buf[17] = 0x22; // Dest Address --> [7:0]
	m_tx_buf[18] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[19] = 0x11; // Source PAN Identifier --> [15:8] MSB
	m_tx_buf[20] = 0x00; // Source Address --> [63:56]
	m_tx_buf[21] = 0x00; // Source Address --> [55:48]
	m_tx_buf[22] = 0x00; // Source Address --> [47:40]
	m_tx_buf[23] = 0x00; // Source Address --> [39:32]
	m_tx_buf[24] = 0x00; // Source Address --> [31:24]
	m_tx_buf[25] = 0x00; // Source Address --> [23:16]
	m_tx_buf[26] = 0x11; // Source Address --> [15:8]
	m_tx_buf[27] = 0x11; // Source Address --> [7:0]
	m_tx_buf[28] = 'A'; // Frame Payload
	m_tx_buf[29] = 'C'; // Frame Payload
	m_tx_buf[30] = 'K'; // Frame Payload
	m_tx_buf[31] = 'N'; // Frame Payload
	m_tx_buf[32] = 'o'; // Frame Payload
	m_tx_buf[33] = 'L'; // Frame Payload
	m_tx_buf[34] = 'E'; // Frame Payload
	m_tx_buf[35] = 'D'; // Frame Payload
	m_tx_buf[36] = 'G'; // Frame Payload
	m_tx_buf[37] = 'E'; // Frame Payload
	//m_tx_buf[38] = asn;
	//m_tx_buf[39] = asn;
	//m_tx_buf[40] = asn;
	//m_tx_buf[41] = asn;
	//m_tx_buf[42] = asn;
	//m_tx_buf[43] = asn;
	//m_tx_buf[44] = asn;
	m_tx_buf[38] = asn;
	m_tx_buf[39] = asn >> 8;
	m_tx_buf[40] = asn >> 16;
	m_tx_buf[41] = asn >> 24;
	m_tx_buf[42] = asn >> 32;
	m_tx_buf[43] = asn >> 40;
	m_tx_buf[44] = asn >> 48;

	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 44; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		BB = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 44) {
			BB |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			BB |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, BB);
		//uint16_t fff = SPI_read_rx_reg(MDP_SPI_1);
		//  printf("0x%X", m_tx_buf[j]); //reading tx buf for debugging

		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);

}


//function for reading the packet that has been sent
void read_Ack() {
	uint16_t BB;
	uint8_t h;
	// Mode 1 memory access mode in read mode (per ADF7030-1 manual)
	m_tx_buf[0] = 0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1
	m_tx_buf[1] = 0x20; //address MSB
	m_tx_buf[2] = 0x00;
	m_tx_buf[3] = 0x0C;
	m_tx_buf[4] = 0x18; //address LSB
	for (h = 5; h <= 44; h++) {
		m_tx_buf[h] = 0x00;
	}
	SPI_init(MDP_SPI_1);
	SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	//GPIO_write_pin(39, 1);
	uint8_t j;
	for (j = 0; j <= 44; j = j + 2) {
		//SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
		BB = ((uint16_t) m_tx_buf[j] << 8);
		if (j + 1 <= 44) {
			BB |= m_tx_buf[j + 1];
		} else {
			/* Padding for odd byte count */
			BB |= 0x00;
		}
		SPI_write_tx_reg(MDP_SPI_1, BB);

		qwq = SPI_read_rx_reg(MDP_SPI_1);
		m_rx_buf[j] = ((qwq >> 8) & 0xFF);  // MSB
		m_rx_buf[j + 1] = (qwq & 0xFF);  // LSB
		delay_us(250);
	}
	SPI_set_CSAAT_pin(MDP_SPI_1, 0);
	// Print payload from byte 30 to 37 (10 chars: HelloWorld)
	for (int i = 30; i < 40; i++) {
		//m_rx_buf[i] = (uint8_t) (qwq);
		printf("%c", m_rx_buf[i]);
	}
	//printing ASN
	long asn = 0;
	for (int i = 0; i < 5; i++) {
		//m_rx_buf[40 + i] = (uint8_t) (qwq);
		asn |= ((long) m_rx_buf[40 + i]) << (8 * i);
	}
	// Print the full ASN number
	printf(" ASN = %lu\n", asn);
}




void READ_PACKET() {

	//read_address(0x20000AF0);
	read_address(0x20000AF0);
	//extracting the data from knk where the data is being stored into a 8bit buffer
	uint8_t i;
//	 for(i=30; i<40; i+2)
	for (i = 0; i <= 139; i += 2) {
		m_rx_buf[i] = (uint8_t) (knk >> 8); //MSB part
		if (i + 1 <= 139) {
			m_rx_buf[i + 1] = (uint8_t) (knk & 0xFF); //LSB
					/*	 printf("0x%X ", m_rx_buf[i]);
					 printf("0x%X ", m_rx_buf[i+1]);*/
			uint16_t TOT = ((uint16_t) m_rx_buf[i] << 8) | m_rx_buf[i + 1];
			printf("0x%02X", TOT);
		} else {
			printf("out of bounds");
		}

		/*printf("%d", m_rx_buf[i]);
		 printf("%c", m_rx_buf[i+1]);*/
	}
	printf("\r");
}



//Adding timeslot fucntionality for ther PAN
void timeslot(void) {
	read_MISC_FW_reg();
	config_all();
	set_GENERIC_PKT_FRAME_CFG5_reg();        // to set the PHR value (length)
	set_GENERIC_PKT_FRAME_CFG1_reg(); //setting interrupt IRQ0 to full packet received interrupt , refer pg 72 of software manual means enabling the interrupt
	write_address(0x20000394, 0x06000000); //mapping pin no 3(GPIO3) to IRQ0 , refer page no 67 of software manual(into ADF's registers as happening onto the side of ADF controlled by our MCU)
	State();
	FSM(CFG_DEV);
	State();
	for (ASN_count = 0; ASN_count < 100000; ASN_count += 1) {

		//app_timer_start(time_out_operation, APP_TIMER_TICKS_US(30000), NULL);
		ASN += 1; // Incrementing the Absolute Slot Number
		printf("#%ld#", ASN);
		//get_time_tx();
		State();
		//logic for transmitting TX on particular channels
		if (ASN % 4 == 1) {
			timeslot_tx();
			printf(" Tx - PAN");
			//printf("\nRx From N2 executing");
		} else if (ASN % 4 == 2) {
			broadcast_EB();
			printf(" EB - PAN");
			//printf("\nEB");
		} else if (ASN % 4 == 3) {
			timeslot_tx();
			printf(" Tx - PAN");
			//printf("\nRx From N1 executing");
		} else {
			timeslot_tx();
			printf(" Tx - PAN");
		}
	}
}


void Test_timeslot_tx() {
	//keeping ASN=1 right now
	//printf(" phy_off state command \n");
	config_all();
	set_GENERIC_PKT_FRAME_CFG5_reg();        // to set the PHR value (length)
	set_GENERIC_PKT_FRAME_CFG1_reg(); //setting interrupt IRQ0 to full packet received interrupt , refer pg 72 of software manual means enabling the interrupt
	write_address(0x20000394, 0x06000000);

	FSM(PHY_OFF);
	delay_us(500);
	FSM(CFG_DEV);
	broadcast_EB(); // for broadcasting beacon or transmitting beacons
	State();

}


//custom adf handler fucntion that would be called in the irq api when external interrupt is raised
void ADF7030InterruptHandler() {
	clear_interrupts();
	State();
	printf("******************Interrupt from ADF_7030_866 MHZ*******************");
	//printf("******************OYe PUNJABI AAGYE OYE*******************");
	delay_us(50);
}

//gpio external interrupt function on receiving interrupt from ADF
void start_gpiote_tx(void) {
	//initializing GPIO pin as input
	//printf("Hello1");
	GPIO_read_pin(IRQ_PIN);	 //using GPIO pin 10 as pin for external interrupt
	//printf("Hello2");
	//enabling external interrupt
	interrupt_enable(GPIO_10_IRQ);
	//printf("Hello3");
	//irq function for calling interrupt handler
	irq_register_handler(GPIO_10_IRQ, ADF7030InterruptHandler);
	//printf("Hello4");
}

