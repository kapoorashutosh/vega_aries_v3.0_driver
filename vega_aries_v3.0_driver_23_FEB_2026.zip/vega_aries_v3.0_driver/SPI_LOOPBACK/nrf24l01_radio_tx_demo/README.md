# Example Programs on VEGA SoCs

pinmap of NRF24L01 to ARTY A7 Board

3v3  --> 3v3
CE pin --> GPIO(0)
GND  --> GND
CSN(SS)  --> SS IO10(J3)
SCK      --> SCLK IO13(J3)
MOSI     --> MOSI IO11(J3)
MISO     --> MISO IO12(J3)



#### and many more... Explore directories for more Programs.
