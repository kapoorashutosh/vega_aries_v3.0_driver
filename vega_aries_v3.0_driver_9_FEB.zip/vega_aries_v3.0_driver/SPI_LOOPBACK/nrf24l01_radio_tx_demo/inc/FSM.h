/*
 * FSM.h
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_

//function varables
extern uint8_t current_state,next_state; // index of current state
//fuction defination declaration
void spi_interface_test();
void invoke_state(uint8_t);
void FSM(uint8_t);
void State(void);
int radio_wait_pll_lock(void);
void wait_until_idle(void);
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"
#endif /* INC_FSM_H_ */
