/***************************************************


 Project Name	: MDP - Microprocessor Development Project
 Project Code	: HD083D
 Created		   : 16-Aug-2021
 Filename		: main.c
 Purpose		   : spi NRF24L01 demo
 Description	: Sample NRF24L01 radio transceiver with spi interface
 Author(s)		: Thomas Sebastian,CDAC
 Email			: vega@cdac.in

 See LICENSE for license details.
 ***************************************************/

/**
 @brief NRF24L01 demo.
 @details interface NRF24L01 module with  spi .
 @param[in] No input parameter. 
 @param[Out] No output parameter. 
*/

#include "stdlib.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason

typedef unsigned short US; // for unsigned short

uint8_t Transmit_Data = 0x45;
//US rxdata = 0;

//#define  Transmit_Data  bData
//#define Receive_Data RxData;

//Initialization function
//void SPI0_Master_Init(void);

//defination function for spi0 and its configuration and parameter settings
//void SPI0_Master_Init(void)
//{
//	//DEFINING STRUCTURE FOR VARIABLE
//	typedef struct {
//	    uint8_t spi_num;
//	    uint8_t mode;
//	    uint8_t clock_polarity;
//	    uint8_t clock_phase;
//	    uint8_t data_order;
//	    uint8_t word_size;
//	    uint8_t rx_tx_intr;
//	    uint8_t baudrate;
//	    uint8_t cs_select;
//	    uint8_t periph_type;
//	} spi_config_t;
//
//	//CONFIGURATION OF SPI0
//
//    spi_config_t spi_cfg;
//    // SPI instance: SPI0
//    spi_cfg.spi_num = MDP_SPI_0;
//    // Set as master
//    spi_cfg.mode = SPI_MODE_MASTER;
//    // SPI Mode 0: CPOL=0, CPHA=0 (idle low, data on 1st edge)
//    spi_cfg.clock_polarity = CPOL_MODE_0;
//    spi_cfg.clock_phase    = CPHA_MODE_0;
//    // MSB first
//    spi_cfg.data_order = MSB;
//    // 8-bit transfer
//    spi_cfg.word_size = BPT_8;
//    // Enable interrupts if needed (set to disable for now)
//    spi_cfg.rx_tx_intr = RX_TX_INTR_DIS;
//    // Set baud rate divider (depends on system clock; start with moderate value)
//    spi_cfg.baudrate = SPI_BAUD_CFD_8;
//    // Select slave using CS line 0 (could be CS_1, CS_2 etc. depending on hardware)
//    spi_cfg.cs_select = SPI_CS_0;
//    // Use fixed peripheral configuration
//    spi_cfg.periph_type = SPI_FIXD_PERIPH;
//    // Initialize the SPI0 interface
//    spi_init(&spi_cfg);
//}




int main()
{

	SPI_init(MDP_SPI_1); // for the SPI0, SPI initialization function with its required configuration for mode 3 (ideal high and data sampled on falling edge [2nd edge])
	SPI_transmit(MDP_SPI_1,  Transmit_Data );
	SPI_receive(MDP_SPI_1 );
	//rxdata=SPI_receive(MDP_SPI_0 );
	printf("Received Data");
   while (1)
   {

      }
   return 0;
   }

