/*
 * read_write_function.h
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_READ_WRITE_FUNCTION_H_
#define INC_READ_WRITE_FUNCTION_H_

#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"

//tx and rx variables for spi transfer and receive

extern uint8_t m_tx_buf[150];
 extern uint8_t m_rx_buf[150];
extern uint16_t zzz;
 //function declaration
 void read_MISC_FW_reg();


#endif /* INC_READ_WRITE_FUNCTION_H_ */
