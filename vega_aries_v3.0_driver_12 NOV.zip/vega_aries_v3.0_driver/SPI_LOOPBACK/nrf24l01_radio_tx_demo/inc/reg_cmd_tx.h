/*
 * reg_cmd_tx.h
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_REG_CMD_TX_H_
#define INC_REG_CMD_TX_H_



//adf7030 state machine radio commands refer pg no. 14 of ADF7030-1 software manual
#define PHY_SLEEP 0x00
#define PHY_OFF 0x01
#define PHY_ON 0x02
#define PHY_RX 0x03
#define PHY_TX 0x04
#define CFG_DEV 0x05
#define CCA 0x06
#define DO_CAL 0x09
#define GPCLK 0x10
#define MON 0x0A
#define LFRC_CAL 0x0C

#define MODE_SWITCH 0x00
#define FCS_TYPE 0x01
#define DATA_WHITENING 0x00



#define macTsTxOffset    1800
#define macTsCca          128
#define macTsRxTx         192
//#define macTsRxOffset     2120
#define macTsMaxTx        4256
#define macTsRxAckDelay   800
#define macTsAckWait      400
#define macTsRxOffset     1020
#define macTsRxWait       2200
#define macTsTxAckDelay   1000
#define macTsMaxAck       2400
#define macTsTimeslotLength 10000

#endif /* INC_REG_CMD_TX_H_ */
