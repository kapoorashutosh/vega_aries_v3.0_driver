/*
 * spi_test.c
 *
 *  Created on: Nov 10, 2025
 *      Author: ashutosh-cdac
 */


//Includes
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/spi_test.h"

void FSM_STATE()
{
	FSM(PHY_ON);
	State();
}
