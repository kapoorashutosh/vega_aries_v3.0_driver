/*
 * FSM.c
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */




/***************************************************


FSM code for VEGA ARIES 3.0 board
*/

#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"

typedef unsigned short US; // for unsigned short
//fucntion variables
uint8_t current_state=0;
uint8_t next_state=0; // index of current state
uint8_t status=0; // input
int radio_state=0;
//uint16_t zzz;
uint8_t Transmit_Data = 0xFF; // command for accessing spi status byte
uint16_t ggg;

void spi_interface_test()
{
	GPIO_write_pin(39, 1);
	//printf("ADF is interfaced with host device");
		SPI_init(MDP_SPI_1); // for the SPI0, SPI initialization function with its required configuration for mode 3 (ideal high and data sampled on falling edge [2nd edge])
		//asserting cs pin from high to low
		//SPI_set_CSAAT_pin(MDP_SPI_1, 0);
		GPIO_write_pin(39, 0);
		//The ADF7030-1 also reports status via a status byte. The ADF7030-1 returns this byte on the SPI MISO pin in response to a no operation
		//(NOP), 0xFF, on the SPI MOSI. The format of the status byte is shown in Table 6. in software manual page 15 of 80
		SPI_transmit(MDP_SPI_1,  Transmit_Data );
		// receiving SPI status byte
		SPI_receive(MDP_SPI_1 );
		//de-asserting cs pin from low to high
		//SPI_set_CSAAT_pin(MDP_SPI_1, 1);
		GPIO_write_pin(39, 1);
		//rxdata=SPI_receive(MDP_SPI_0 );
		printf("ADF is interfaced with host device");
}



//void invoke_state(uint8_t current_state1)
void invoke_state(uint8_t current_state1)
{
	//printf("gffhfhfh");
       m_tx_buf[0]=(current_state)|(0x80);    //invoke state radio command
       m_tx_buf[1]=0xff;
       //GPIO_write_pin(39, 1); //setting cs pin high as cssat in spiint is low by default
      // GPIO_write_pin(39, 1);
       SPI_init(MDP_SPI_1);
      SPI_set_CSAAT_pin(MDP_SPI_1, 1);
       //GPIO_write_pin(39, 0);
       uint8_t i;
       for(i=0; i<1; i++){
    	   uint16_t WORD = ((uint16_t)m_tx_buf[i] << 8) | m_tx_buf[i+1];
    	   SPI_write_tx_reg(MDP_SPI_1, WORD);
    	   ggg = SPI_read_rx_reg(MDP_SPI_1);
    	   //m_rx_buf[j] = (uint8_t)ggg;
    	  //printf("gffhfhfh");
      // m_rx_buf[j]= (uint8_t)SPI_receive(MDP_SPI_1 );
       }
       delay_us(250);
      SPI_set_CSAAT_pin(MDP_SPI_1, 0);
       //GPIO_write_pin(39, 1);

}



//function for changing state of adf
void FSM(uint8_t input)
{

  State();
  char flag=0;
  if(status==0)
    flag=1;
  if(input != current_state)
  {
  printf("\t%x \t",input);
  switch(input)
  {
  case 0x00: if(current_state==PHY_OFF||current_state==PHY_ON)
          {
            next_state = PHY_SLEEP;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x01: if(current_state==PHY_ON)
          {
            next_state = PHY_OFF;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x02: if(current_state==PHY_OFF||current_state==PHY_RX||current_state==PHY_TX||current_state==CCA)
          {
            next_state = PHY_ON;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x03: if(current_state==PHY_ON||current_state==PHY_TX||current_state==PHY_RX)
          {
            next_state = PHY_RX;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x04: if(current_state==PHY_ON||current_state==PHY_TX||current_state==PHY_RX||current_state==CCA)
          {
            next_state = PHY_TX;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x05: if(current_state==PHY_OFF)
          {
            next_state = CFG_DEV;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x06: if(current_state==PHY_ON)
          {
            next_state = CCA;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x09: if(current_state==PHY_ON)
          {
            next_state = DO_CAL;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x10: if(current_state==PHY_ON)
          {
            next_state = GPCLK;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x0A: if(current_state==PHY_ON)
          {
            next_state = MON;
          }
          else
          {
            flag=1;
          }
          break;
  case 0x0C: if(current_state==PHY_ON)
          {
            next_state = LFRC_CAL;
          }
          else
          {
            flag=1;
          }
          break;
  default:flag=1;
          break;
  }
current_state=next_state;
if(flag==0)
  invoke_state(current_state);
else
  printf("INVALID STATE TRANSITION");
}
else
  printf("Already in the commanded state");
}


//state fucntion for getting the fsm state of adf radio
void State()
{
	//printf("Hello");
  read_MISC_FW_reg();
 // state=0;
  //printf("Hello");
  //radio_state=m_rx_buf[9]&(0x3F);
  //status=m_rx_buf[10]&(0x03);
  m_rx_buf[9] = (uint8_t)(zzz & 0xFF); //9th byte
  m_rx_buf[10] = (uint8_t)(zzz & 0xFF); //10th byte
  radio_state=m_rx_buf[9]&(0x3F);
  status=m_rx_buf[10]&(0x03);

  switch(radio_state)
  {
    case PHY_SLEEP : printf("Radio is in SLEEP and ");
                     current_state=PHY_SLEEP;
                     break;
    case PHY_OFF : printf("Radio is in PHY_OFF and ");
                   current_state=PHY_OFF;
                   break;
    case PHY_ON : printf("Radio is in PHY_ON and ");
                  current_state=PHY_ON;
                  break;
    case PHY_RX : printf("Radio is in PHY_RX and ");
                  current_state=PHY_RX;
                  break;
    case PHY_TX : printf("Radio is in PHY_TX and ");
                  current_state=PHY_TX;
                  break;
    case CFG_DEV : printf("Radio is in Configuring and ");
                   current_state=CFG_DEV;
                   break;
    case CCA : printf("Radio is in CCA and ");
               current_state=CCA;
               break;
    case DO_CAL : printf("Radio is in Caliberating and ");
                  current_state=DO_CAL;
                  break;
    case MON : printf("Radio is in Monitoring and ");
               current_state=MON;
               break;
    case GPCLK : printf("Radio is in GPCLK state and ");
               current_state=GPCLK;
               break;
    case LFRC_CAL : printf("Radio is in LFRC_CAL state  and ");
               current_state=LFRC_CAL;
               break;
    default : printf(" *************Error State undefined ************* ");
              status=3;
              break;
  }
 // state=0;
  switch(status)
  {
    case 0 : printf("Transitioning state\n");
             break;
    case 1 : printf("Executing state\n");
             break;
    case 2 : printf("idle state\n");
           //  state=1;
             break;
    default: printf("\n");
             break;
  }
  printf("\n");
}




