/*
 * delay.c
 *
 *  Created on: May 26, 2025
 *      Author: ashutosh
 */
#include "inc/delay.h"

// Define CPU clock frequency
#define CPU_CLOCK_HZ 100000000U  // 100 MHz

// Approximate cycles per loop iteration
#define CYCLES_PER_LOOP 4

void delay_us(uint32_t us)
{
    // Calculate number of iterations for requested microsecond delay
    uint32_t iterations = (CPU_CLOCK_HZ / 1000000U / CYCLES_PER_LOOP) * us;

    while (iterations--)
    {
        __asm__ volatile ("nop");
    }
}

void delay_ms(uint32_t ms)
{
    while (ms--)
    {
        delay_us(1000U);
    }
}
