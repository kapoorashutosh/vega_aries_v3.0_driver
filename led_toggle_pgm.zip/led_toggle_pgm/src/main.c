/*
 * main.c
 *
 *  Created on: May 23, 2025
 *      Author: ashutosh
 */
#include "stdlib.h"
#include "config.h"
#include "gpio.h"
#include "led.h" // does'nt require i just added this for no use
#include"stdint.h"

#include "../INC/delay.h"

#define LED_GREEN 22
#define LED_BLUE  23
#define LED_RED   24
uint8_t i;
// the write function  automatically sets the pin to output mode whereas read sets it to input i.e GPIO INPUT OR GPIO OUTPUT
void led_off_all() {
	GPIO_write_pin(LED_RED, 1); // pull down register configuration
	GPIO_write_pin(LED_GREEN, 1);
	GPIO_write_pin(LED_BLUE, 1);
}

int main() {
//    // Configure RGB pins as outputs
//	 GPIO_set_direction(LED_GREEN, GPIO_OUTPUT);
//    gpio_init(LED_BLUE, GPIO_OUTPUT);
//    gpio_init(LED_RED, GPIO_OUTPUT);
//	GPIO_write_pin(LED_RED, 1);

	        //for(i=0; i< 12500000; i++); //delay( 500ms delay time)
	    	   //led_off_all();
	        // GREEN
	    // led_off_all();
	    //GPIO_write_pin(LED_GREEN, 0);
	  //  for(i=0; i< 12500000; i++); //delay

	        // BLUE

	     //   GPIO_write_pin(LED_BLUE, 1);
	       //for(i=0; i< 12500000; i++); //delay
	        //  led_off_all();
    while (1) {
        // RED

    	GPIO_write_pin(LED_RED, 0);

    	delay_ms(500);
    			  led_off_all();
        // GREEN

    GPIO_write_pin(LED_GREEN, 0);

    delay_ms(500);
    	led_off_all();
        // BLUE

        GPIO_write_pin(LED_BLUE, 0);

        delay_ms(500);
        	   led_off_all();

    }

    return 0;
}



