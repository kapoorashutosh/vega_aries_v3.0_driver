/*
 * read_write_function.c
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"
 uint8_t m_tx_buf[150];   //TX buffer
 uint8_t m_rx_buf[150];  //RX buffer

// function defination for FSM state memory access register
 void read_MISC_FW_reg()
 {      // mode 1 memory access mode in read mode  (pg no 47 of ADF software manual)
        m_tx_buf[0]=0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1, MHPTR=000 (dont care) -->01111000
        m_tx_buf[1]=0x40;  // 1st Byte (MSB)
        m_tx_buf[2]=0x00;  //2nd Byte
        m_tx_buf[3]=0x42;  //3rd Byte
        m_tx_buf[4]=0xB4;  //4th Byte (LSB)
        SPI_init(MDP_SPI_1);
        SPI_set_CSAAT_pin(MDP_SPI_1, 1);
        uint8_t j,z;
        for(j=0; j<=4; j++){
        SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
        }
        for(z=0; z<=10; z++){
        m_rx_buf[z] = (uint8_t)SPI_receive(MDP_SPI_1 );
        }
        delay_us(100);
        SPI_set_CSAAT_pin(MDP_SPI_1, 0);
        //nrf_drv_spi_transfer(&spi,m_tx_buf,5,m_rx_buf,11);
        //Although we are reading 11 bytes 1st 7 bytes will be status bytes next 4 bytes is the data from ADF to host
        //nrf_delay_us(100);
        //for(i=7;i<11;i++)
        // printf("m_rx_buff[%d]: %x \n",i, m_rx_buf[i]);
 }
