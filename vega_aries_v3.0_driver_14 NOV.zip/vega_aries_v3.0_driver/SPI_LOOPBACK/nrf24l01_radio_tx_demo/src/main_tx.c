/*
 * main_tx.c
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
//file inculdes
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/spi_test.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"


int main()
{

	printf("Hello");
//	State();
//	FSM(PHY_ON);
	for(ASN_count=0;ASN_count<100000;ASN_count+=1)
	    {
		ASN+=1; // Incrementing the Absolute Slot Number
	    }

    printf("My world");
   while (1)
   {

      }
   return 0;
   }
