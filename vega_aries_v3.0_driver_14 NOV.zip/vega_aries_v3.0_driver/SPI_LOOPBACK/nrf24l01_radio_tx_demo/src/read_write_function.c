/*
 * read_write_function.c
 *
 *  Created on: Nov 4, 2025
 *      Author: ashutosh-cdac
 */
#include "stdlib.h"
#include "gpio.h"
#include "spi.h"
#include "stdint.h"
#include "config.h"
#include "inc/delay.h"// not needed to be include just included for no reason
#include "timer.h"
#include "stdbool.h"
//file inculdes
//#include "reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/reg_cmd_tx.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/FSM.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/read_write_function.h"
#include "/home/ashutosh-cdac/eclipse-workspace/vega_aries_v3.0_driver/SPI_LOOPBACK/nrf24l01_radio_tx_demo/inc/timer_tx.h"
 uint8_t m_tx_buf[150];   //TX buffer
 uint8_t m_rx_buf[150];  //RX buffer
 uint16_t zzz; // 16 bit receive buffer
 uint32_t adf_freq,f;
 int length = 0;
  int pad_data = 0;
 //long ASN =0;
 int look_up_table[4]={0x337055C0,0x3371DC60,0x33736300,0x3374E9A0};   // Look up table for frequecy hopping
 long ASN =0;
 int ASN_count=0;
 long asn;
 int CurTimeslot=0;
 //uint8_t ax;
 //uint8_t bx;
 struct LinkTable
 {
   int macLinkHandle;
   uint8_t state; //macRxType<<1|macTxType
   bool macSharedType;
   bool macLinkTimeKeeping;
   bool macPriorityType;
   bool macLinkType;
   bool macNodeAddressMode; //0 for long addres 1 for short address. In standard
   double macNodeAddress;
   int macTimeslot;
   int macChannelOffset;
   bool macLinkAdvertise;
 } macLinkTable[4];


 void set_GENERIC_PKT_FRAME_CFG5_reg()
 {
      //Memory acccess mode 1 in write format
       read_address(0x200000510);
       int TX_PHR=(MODE_SWITCH<<15)|0x0000|(FCS_TYPE<<12)|(DATA_WHITENING<<11)|((length + 2)& 0x07FF);//0X0149 FOR EB of length 72
       printf("\nTX_PHR %x", TX_PHR);
       m_tx_buf[0]=0x38;  //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
       m_tx_buf[1]=0x20; //1st byte ofAddress of the register
       m_tx_buf[2]=0x00; //2nd byte ofAddress of the register
       m_tx_buf[3]=0x05; //3rd byte ofAddress of the register
       m_tx_buf[4]=0x10; //4th byte ofAddress of the register
       m_tx_buf[5]=m_rx_buf[7];   //1st byte
       m_tx_buf[6]=m_rx_buf[8];   //2nd byte
       m_tx_buf[7]=TX_PHR>>8;   //#rd byte
       m_tx_buf[8]=TX_PHR;   //4th byte
 }
// function defination for FSM state memory access register
 void read_MISC_FW_reg()
 {      // mode 1 memory access mode in read mode  (pg no 47 of ADF software manual)
        m_tx_buf[0]=0x78; // CNM=0, RNW=1, BNR=1, ANP=1, LNS=1, MHPTR=000 (dont care) -->01111000
        m_tx_buf[1]=0x40;  // 1st Byte (MSB)
        m_tx_buf[2]=0x00;  //2nd Byte
        m_tx_buf[3]=0x42;  //3rd Byte
        m_tx_buf[4]=0xB4;  //4th Byte (LSB)
        m_tx_buf[5] = 0x00;  // Dummy bytes to clock out remaining data
        m_tx_buf[6] = 0x00;
        m_tx_buf[7] = 0x00;
        m_tx_buf[8] = 0x00;
        m_tx_buf[9] = 0x00;
        m_tx_buf[10] = 0x00;
      //  GPIO_write_pin(39, 1); //setting cs pin high as cssat in spiint is low by default

        SPI_init(MDP_SPI_1);
       SPI_set_CSAAT_pin(MDP_SPI_1, 1);
        //GPIO_write_pin(39, 1);
        uint8_t j;
       // uint8_t z =4;
        //i = 0 → 0x78 << 8 | 0x40 → 0x7840
      //  i = 2 → 0x00 << 8 | 0x42 → 0x0042
       // i = 4 → 0xB4 << 8 | 0x00 → 0xB400   (padded)

        for(j=0; j<=10; j=j+2){
        //SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
       uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | m_tx_buf[j+1];
       //uint16_t word = ((uint16_t)m_tx_buf[j] << 8) | 0x00;

        SPI_write_tx_reg(MDP_SPI_1, word);
         zzz = SPI_read_rx_reg(MDP_SPI_1);
         //if(z <= 4)  // Changed from z<=5 to z<=4 since we write 2 bytes per iteration
         //{
//             m_rx_buf[j] = (uint8_t)(zzz >> 8);       // MSB first
//             m_rx_buf[j+1] = (uint8_t)(zzz & 0xFF);   // LSB next
         m_rx_buf[j] = (uint8_t)(zzz >> 8);      // MSB position
             m_rx_buf[j+1] = (uint8_t)(zzz & 0xFF); //lSB position
             //m_rx_buf[j] = zzz;
         //}
       // m_rx_buf[z] = (uint8_t)SPI_receive(MDP_SPI_1, 0 );

        delay_us(100);
        }
        //GPIO_write_pin(39, 1);
        SPI_set_CSAAT_pin(MDP_SPI_1, 0);
        //nrf_drv_spi_transfer(&spi,m_tx_buf,5,m_rx_buf,11);
        //Although we are reading 11 bytes 1st 7 bytes will be status bytes next 4 bytes is the data from ADF to host
        //nrf_delay_us(100);
        //for(i=7;i<11;i++)
        // printf("m_rx_buff[%d]: %x \n",i, m_rx_buf[i]);
//        m_rx_buf[4] = (uint8_t)(zzz); //9th byte
//        m_rx_buf[5] = (uint8_t)(zzz>>8); //10th byte
//        radio_state=m_rx_buf[4]&(0x3F);
//        status=m_rx_buf[5]&(0x03);
 }




  void channel_write(long asn)
 {
	 uint8_t x= (asn + macLinkTable[CurTimeslot].macChannelOffset) % 4;
	 adf_freq = look_up_table[x] ;
	 m_tx_buf[0] = 0x38;                                  // Command to write the channel frequency in the ADF Register (Lower byte first)
	        m_tx_buf[1] = 0x20;                     //address of the freaquency register in 7030 0x200002EC,
	        m_tx_buf[2] = 0x00;
	        m_tx_buf[3] = 0x02;
	        m_tx_buf[4] = 0xEC;
	        m_tx_buf[5] = (adf_freq >> 24);
	        m_tx_buf[6] = (adf_freq >> 16);
	        m_tx_buf[7] = (adf_freq >> 8);
	        m_tx_buf[8] =  adf_freq;

	        SPI_init(MDP_SPI_1);
	             SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	              //GPIO_write_pin(39, 1);
	              uint8_t j;
	              for(j=0; j<=8; j=j+2){
	              //SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
	             uint16_t AA= ((uint16_t)m_tx_buf[j] << 8) | m_tx_buf[j+1];
	              SPI_write_tx_reg(MDP_SPI_1, AA);
	               uint16_t ccc = SPI_read_rx_reg(MDP_SPI_1);
	              }
	                    delay_us(250);
	                   SPI_set_CSAAT_pin(MDP_SPI_1, 0);
 }

  void write_Packet(long asn)
  {
	  length=40;
	  check_length_and_padding();
	  set_GENERIC_PKT_FRAME_CFG5_reg();
	  //Memory acccess mode 1 in write format
	        m_tx_buf[0]=0x38;  //Memory access command CNM=0, RNW=0, BNR=1, ANP=1, LNS=1, MHPTR=000 --> 0011 1000
	        m_tx_buf[1]=0x20; //1st byte ofAddress of the register
	        m_tx_buf[2]=0x00; //2nd byte ofAddress of the register
	        m_tx_buf[3]=0x0A; //3rd byte ofAddress of the register
	        m_tx_buf[4]=0xF0; //4th byte ofAddress of the register
	        m_tx_buf[5] = 0xDC; // FCF --> Frame control field [15:8] MSB
	        m_tx_buf[6] = 0x51; // FCF --> Frame control field [7:0] LSB
	        m_tx_buf[7] = 0x1C; // SEQ NUM -->Sequence number
	        m_tx_buf[8] = 0x22; // Dest PAN Identifier --> [15:8] MSB
	        m_tx_buf[9] = 0x22; // Dest PAN Identifier --> [7:0] MSB
	        m_tx_buf[10] = 0x00; // Dest Address --> [63:56]
	        m_tx_buf[11] = 0x00; // Dest Address --> [55:48]
	        m_tx_buf[12] = 0x00; // Dest Address --> [47:40]
	        m_tx_buf[13] = 0x00; // Dest Address --> [39:32]
	        m_tx_buf[14] = 0x00; // Dest Address --> [31:24]
	        m_tx_buf[15] = 0x00; // Dest Address --> [23:16]
	        m_tx_buf[16] = 0x22; // Dest Address --> [15:8]
	        m_tx_buf[17] = 0x22; // Dest Address --> [7:0]
	        m_tx_buf[18] = 0x11; // Source PAN Identifier --> [15:8] MSB
	        m_tx_buf[19] = 0x11; // Source PAN Identifier --> [15:8] MSB
	        m_tx_buf[20] = 0x00; // Source Address --> [63:56]
	        m_tx_buf[21] = 0x00; // Source Address --> [55:48]
	        m_tx_buf[22] = 0x00; // Source Address --> [47:40]
	        m_tx_buf[23] = 0x00; // Source Address --> [39:32]
	        m_tx_buf[24] = 0x00; // Source Address --> [31:24]
	        m_tx_buf[25] = 0x00; // Source Address --> [23:16]
	        m_tx_buf[26] = 0x11; // Source Address --> [15:8]
	        m_tx_buf[27] = 0x11; // Source Address --> [7:0]
	        m_tx_buf[28] = 'H'; // Frame Payload
	        m_tx_buf[29] = 'E'; // Frame Payload
	        m_tx_buf[30] = 'l'; // Frame Payload
	        m_tx_buf[31] = 'l'; // Frame Payload
	        m_tx_buf[32] = 'o'; // Frame Payload
	        m_tx_buf[33] = 'W'; // Frame Payload
	        m_tx_buf[34] = 'o'; // Frame Payload
	        m_tx_buf[35] = 'r'; // Frame Payload
	        m_tx_buf[36] = 'l'; // Frame Payload
	        m_tx_buf[37] = 'd'; // Frame Payload
	        m_tx_buf[38] = asn;
	        m_tx_buf[39] = asn>>8;
	        m_tx_buf[40] = asn>>16;
	        m_tx_buf[41] = asn>>24;
	        m_tx_buf[42] = asn>>32;
	        m_tx_buf[43] = asn>>40;
	        m_tx_buf[44] = asn>>48;

	        SPI_init(MDP_SPI_1);
	        	             SPI_set_CSAAT_pin(MDP_SPI_1, 1);
	        	              //GPIO_write_pin(39, 1);
	        	              uint8_t j;
	        	              for(j=0; j<=44; j=j+2){
	        	              	              //SPI_transmit(MDP_SPI_1, m_tx_buf[j] );
	        	              	             uint16_t BB= ((uint16_t)m_tx_buf[j] << 8) | m_tx_buf[j+1];
	        	              	              SPI_write_tx_reg(MDP_SPI_1, BB);
	        	              	               uint16_t fff = SPI_read_rx_reg(MDP_SPI_1);
	        	              	              }
	        	              	                    delay_us(250);
	        	              	                   SPI_set_CSAAT_pin(MDP_SPI_1, 0);
  }





  void check_length_and_padding()
  {
	  uint8_t i = 0;
    if(length % 4 != 0)
    {
      pad_data = (4 - length%4);
      for(i = length+5;i<length+5+pad_data;i++)
      {
        m_tx_buf[i] = 0xBB;
        printf("\t%x\t%d",m_tx_buf[i],i);

      }
      length = length + pad_data;
      printf("\the length after padding is %d",length);
    }
    else
      printf(" NO Padding ");
  }

  //timeslot function for tx
 void timeslot_tx()
 {
	 channel_write(ASN);// writing frequency to register
	 write_Packet(ASN);//change phr/
 }




