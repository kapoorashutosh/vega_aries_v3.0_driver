/*
 * FSM.h
 *
 *  Created on: Oct 30, 2025
 *      Author: ashutosh-cdac
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_

//function varables
extern uint8_t current_state,next_state; // index of current state
//fuction defination declaration
void spi_interface_test();
void invoke_state(uint8_t);
void FSM(uint8_t);
void State(void);
#endif /* INC_FSM_H_ */
